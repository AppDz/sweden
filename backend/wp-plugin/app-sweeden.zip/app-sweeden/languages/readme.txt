Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_sweeden-de_DE.po
* app_sweeden-id_ID.po
* app_sweeden_ES.po
* app_sweeden-en_US.po
* app_sweeden-de_DE.mo
* app_sweeden-id_ID.mo
* app_sweeden-es_ES.mo
* app_sweeden-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
